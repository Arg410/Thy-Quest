nav = new SceneNavigator(["startup"]);
stats = {};

