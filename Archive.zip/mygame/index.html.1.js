
// INSERT store name; disabled by default because it's confusing for newbie authors
window.storeName = null;
//Scene.generatedFast = true;
var rootDir = "../";
